package com.smartinventory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartInventoryManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
